﻿namespace _2juneADAuth.Models
{
    public class userInput
    {
        public string? Ticker { get; set; }
    }
}
